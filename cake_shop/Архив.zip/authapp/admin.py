from django.contrib import admin

from authapp.models import User

# Register your models here.
admin.site.register(User)