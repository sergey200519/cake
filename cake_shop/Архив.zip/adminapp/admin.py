from django.contrib import admin

from adminapp.models import Applications

# Register your models here.
admin.site.register(Applications)